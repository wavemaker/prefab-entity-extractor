Add your test resources such as properties and xml files to this folder.
