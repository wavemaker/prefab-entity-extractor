/*Copyright (c) 2015-2016 imaginea-com All Rights Reserved.
 This software is the confidential and proprietary information of imaginea-com You shall not disclose such Confidential Information and shall use it only in accordance
 with the terms of the source code license agreement you entered into with imaginea-com*/
package com.entityextraction.fieldsextractionservice;

import javax.servlet.http.HttpServletRequest;

import java.io.*;
import java.net.*;

import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.nio.ByteBuffer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.json.*;

import org.apache.commons.text.similarity.LevenshteinDistance;
import org.apache.commons.lang3.StringUtils;



import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import com.wavemaker.runtime.service.annotations.HideFromClient;
import com.wavemaker.commons.WMRuntimeException;


import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.textract.AmazonTextractClientBuilder;
import com.amazonaws.services.textract.AmazonTextract;
import com.amazonaws.services.textract.model.*;

import com.amazonaws.auth.EnvironmentVariableCredentialsProvider;
import com.amazonaws.auth.SystemPropertiesCredentialsProvider;
import com.amazonaws.util.IOUtils;



//import com.entityextraction.fieldsextractionservice.model.*;

/**
 * This is a singleton class with all its public methods exposed as REST APIs via generated controller class.
 * To avoid exposing an API for a particular public method, annotate it with @HideFromClient.
 *
 * Method names will play a major role in defining the Http Method for the generated APIs. For example, a method name
 * that starts with delete/remove, will make the API exposed as Http Method "DELETE".
 *
 * Method Parameters of type primitives (including java.lang.String) will be exposed as Query Parameters &
 * Complex Types/Objects will become part of the Request body in the generated API.
 *
 * NOTE: We do not recommend using method overloading on client exposed methods.
 */
@ExposeToClient
public class FieldsExtractionService {

    private static final Logger logger = LoggerFactory.getLogger(FieldsExtractionService.class);

    @Autowired
    private SecurityService securityService;
    
    @Value("${app.environment.AWS_ACCESS_KEY_ID}")
	private String awsAccessKey;
	
	@Value("${app.environment.AWS_SECRET_ACCESS_KEY}")
	private String awsSecretKey;
	
	@Value("${app.environment.AWS_REGION}")
	private String 	awsRegion;
	
	
	/**
	 * Public method which can be exposed as a REST API.
	 */
	public String getEntityValues(List<String> entities, String documentURL) {
	    logger.info("FieldNames " + entities.toString());
        logger.info("DocumentURL " + documentURL);
        
        // Input validation
        if(documentURL==null || documentURL.isEmpty()) {
            throw new WMRuntimeException("Document URL is empty.");
        }
         if(entities==null || entities.isEmpty()) {
            throw new WMRuntimeException("Required entities list (input) is empty.");
        }
        
        // Output 
        String output = processDocument(entities, documentURL);
        logger.info("output " + output);

        return output;
	}
	
	
	private String processDocument(List<String> entities, String documentURL) {
	    JSONObject out = new JSONObject();
	    ByteBuffer docBytes = docToBytes(documentURL);
	    //AWS Textract
	    AmazonTextract client = getAWSTextractClient();
	    HashMap<String, String> keyValuesMap = analyzeDocument(client, "FORMS", docBytes);
	    for (String entity : entities) {
	        // Entity clean-up
	        String processed_entity = getLowerCasedString(entity);
	        processed_entity = normalizeStringSpace(processed_entity);
	        
	        int d = processed_entity.length();
	        String value_init = "";
	        for (Map.Entry<String, String> entry : keyValuesMap.entrySet()) {
	            String key = getLowerCasedString(entry.getKey());
	            key = normalizeStringSpace(key);
	            String value = entry.getValue();
	            int v = new LevenshteinDistance().apply(processed_entity, key);

	            if(v < d) {
	                d = v;
	                value_init = value.trim();
	                
	            }
	        }
	        out.put(entity, value_init);
	        
	    }
	   // logger.info("output " + out.toString());

	    
	    return out.toString();
	}
    
   // ---------------------------------------------------------------------------------------------------------------------------------
   //Utills
    
    /**
     * This method used to convert document(png,jpg,or pdf) to bytes with document URL.
     * Currently this step required to call AWS Textract API, since it accepts only bytes or document S3 path.
     * 
     */
    private ByteBuffer docToBytes(String documentURL) {
        ByteBuffer docBytes = null;
        InputStream is = null;
        try {
            URL url = new URL(documentURL);
            is = url.openStream();
            docBytes = ByteBuffer.wrap(IOUtils.toByteArray(is));
        } catch (Exception e) {
             throw new WMRuntimeException("Exception at converting document to byte array -- {}", e);

        } finally {
            try {
                if(is!=null) is.close();
            } catch(IOException e) {
                throw new WMRuntimeException("Exception at converting document to byte array -- {}", e);
                
            }
    
        }
        
        return docBytes;
    }
    
    /**
     * This method id used to convert every string to lowercase. 
     * If input string is null or empty then return same.
     */
    private String getLowerCasedString(String str) {
        
        if(str==null || str.isEmpty()) {
            return str;
        }
        else {
            return str.trim().toLowerCase();
        }
        
    }
    
    private String normalizeStringSpace(String str) {
        return StringUtils.normalizeSpace(str.replace(",", " "));
        
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------------------
    // AWS Textract
    
    private AmazonTextract getAWSTextractClient() {
        try {
            System.setProperty("aws.accessKeyId", awsAccessKey);
            System.setProperty("aws.secretKey", awsSecretKey);
            String textractEndpoint = "https://textract." + awsRegion + ".amazonaws.com";
            EndpointConfiguration endpoint = new EndpointConfiguration(textractEndpoint, awsRegion);
            AmazonTextract client = AmazonTextractClientBuilder.standard().withCredentials(new SystemPropertiesCredentialsProvider()).withEndpointConfiguration(endpoint).build();
            return client;
        } catch (Exception e) {
            throw new WMRuntimeException("Exception at getting AWS Textract client. Make sure AWS Access/security keys and region are valid");
            
        }
        
    }
    
    private HashMap<String, String> analyzeDocument(AmazonTextract client,String type,  ByteBuffer imageBytes) {
        try {
            AnalyzeDocumentRequest request = new AnalyzeDocumentRequest().withFeatureTypes(type).withDocument(new Document().withBytes(imageBytes));
            AnalyzeDocumentResult result = client.analyzeDocument(request);
            List<Block> blocks = result.getBlocks();
            
            HashMap<String, Block> blocksMap = new HashMap<>();
            HashMap<String, Block> keyBlocksMap = new HashMap<>();
            HashMap<String, Block> valueBlocksMap = new HashMap<>(); 
           
            for (Block block : blocks) {
                String blockId = block.getId();
                blocksMap.put(blockId, block);
                if ((block.getBlockType()).equals("KEY_VALUE_SET")) {
                    if ((block.getEntityTypes()).contains("KEY")) {
                        keyBlocksMap.put(blockId, block);
                    }
                    else {
                        valueBlocksMap.put(blockId, block);
                    }
                }
            }
            
            HashMap<String, String> keyValues = new HashMap<>();
       
            for (Map.Entry<String, Block> entry : keyBlocksMap.entrySet()) {
                String key = entry.getKey();
                Block keyBlock = entry.getValue();
                Block valueBlock = getValueBlock(keyBlock, valueBlocksMap);
                String keyText = getText(keyBlock, blocksMap);
                String valueText = getText(valueBlock, blocksMap);
              
                keyValues.put(keyText, valueText);
            }
            
            return keyValues;
            
        } catch (Exception e) {
            throw new WMRuntimeException("Exception at analyzing document using AWS Textract - {} ", e);
        }
    }
    
    private Block getValueBlock(Block keyBlock, HashMap<String, Block> blockValues) {
        Block valueBlock = null;
        List<Relationship> relations = keyBlock.getRelationships();
        for (Relationship relation : relations) {
            if ((relation.getType()).equals("VALUE")) {
                for (String id : relation.getIds()) {
                    valueBlock = blockValues.get(id);
                    
                }
            }
        }
        
        return valueBlock;
    }
    
    private String getText(Block keyBlock, HashMap<String, Block> blockIds) {
        String field = "";
        List<Relationship> relationships=keyBlock.getRelationships();
        if(relationships!=null) {
            for (Relationship relation : relationships) {
                if ((relation.getType()).equals("CHILD")) {
                    for (String id : relation.getIds()) {
                        Block wordBlock = blockIds.get(id);
                        if ((wordBlock.getBlockType()).equals("WORD")) {
                            field = field.concat(wordBlock.getText()+" ");
                        }
                        
                    }
                    
                }
                
            }
            
        }
        
        return field;
    }

}