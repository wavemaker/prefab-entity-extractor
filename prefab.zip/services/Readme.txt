All the services will be created in this folder.
